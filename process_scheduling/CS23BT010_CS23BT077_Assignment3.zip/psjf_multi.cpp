#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <cstring>
#include <unistd.h>
#include <signal.h>
#include <queue>
#include <sstream>
#include <algorithm>
#include <chrono>
using namespace std;

#define MAX_CPUS 2
bool  debug = false;
bool cpu_busy[MAX_CPUS];
int running_process[MAX_CPUS];
void finished(int pid, int cpu_id);
void got_ready(int pid);
void terminate(int pid);

int terminated_processes = 0;
class Process
{
private:
    bool cpuBurst = true;

public:
    int arrival_time;
    vector<int> cpu_burst_times;
    vector<int> io_times;
    // io_times.push_back(0);
    string state = "ready";
    int proc_no;

    int turn_around_time;
    int cpu_time_rem;

    int cpu_index = 0;
    int io_index = 0;
    int io_time_rem;
    bool preempt = false;
    int cpu_id;
    long long got_ready_at;
    long long started_burst_at;
    vector<vector<long long>> burst_times;
    int pid;

    int bust_count = 0;

    Process(int arr_time, int id)
    {
        arrival_time = arr_time;
        pid = id;
        burst_times = vector<vector<long long>>(0, vector<long long>(3, 0));
        got_ready_at = arr_time;
    }

    int add_cpu_time(int cpu_time)
    {
        cpu_burst_times.push_back(cpu_time);
        if(debug) cout << "Added cput" << cpu_time << endl;
        cpu_time_rem = cpu_burst_times[0];
        return 0;
    }
    int add_IO_time(int IO_time)
    {
        io_times.push_back(IO_time);
        if(debug) cout << "Added iot" << IO_time << endl;
        io_time_rem = io_times[0];
        return 0;
    }

    void update(long long time)
    {
        if (state == "running")
        {
            if(debug) cout << "Process " << pid << " running, time rem " << cpu_time_rem << endl;
            if (cpu_time_rem > 0)
            {
                cpu_time_rem--;
            }
            if (cpu_time_rem == 0)
            {
                finished(pid, cpu_id);
                burst_times.push_back({started_burst_at, time, cpu_id});
                cpu_index++;
                if (cpu_index < cpu_burst_times.size())
                {
                    state = "waiting";
                    io_time_rem = io_times[io_index];
                    io_index++;
                    if(debug) cout << "Process " << pid << " finished and going to wait state for " << io_time_rem << endl;
                }
                else
                {
                    state = "terminated";
                    turn_around_time = time - arrival_time + 1;
                    terminate(pid);
                }
            }
        }

        else if (state == "waiting")
        {
            if (io_time_rem > 0)
            {
                io_time_rem--;
            }
            if (io_time_rem == 0)
            {
                state = "ready";
                if (cpu_index < cpu_burst_times.size())
                {
                    got_ready(pid);
                    cpu_time_rem = cpu_burst_times[cpu_index];
                }
                else
                {
                    state = "terminated";
                }
            }
        }
    }

    int get_next_cpu_burst()
    {
        if (preempt || state == "running")
            return cpu_time_rem;
        if (cpu_index < cpu_burst_times.size())
            return cpu_burst_times[cpu_index];
        return -1;
    }

    void run(long long time, int cpu_no)
    {
        state = "running";
        started_burst_at = time;
        cpu_id = cpu_no;
        preempt = false;
    }

    void stop(long long time)
    {
        state = "ready";
        burst_times.push_back({started_burst_at, time, cpu_id});
        got_ready_at = time;
        cpu_id = -1;
        preempt = true;
    }
};

class comp
{
public:
    bool operator()(Process *p1, Process *p2)
    {
        return p1->get_next_cpu_burst() > p2->get_next_cpu_burst();
    }
};

priority_queue<Process *, vector<Process *>, comp> prq;
vector<Process> processes;

void finished(int pid, int cpu_id)
{

    cpu_busy[cpu_id] = false;
    running_process[cpu_id] = -1;
}

void got_ready(int pid)
{
    if(debug) cout << "Process " << pid << " got ready\n";
    prq.push(&processes[pid - 1]);
}

void terminate(int pid)
{
    terminated_processes++;
}
void getInput(string filename)
{
    ifstream file(filename);
    string line;
    getline(file, line);
    while (line[0] == '<')
    {
        getline(file, line);
    }
    int pid = 1;

    while (1)
    {
        stringstream ss;
        ss << line;
        if (line[0] == '<')
            break;
        int x;
        ss >> x;
        Process np(x, pid);
        pid++;
        bool cpu_time = true;
        ss >> x;
        while (x != -1)
        {
            if (cpu_time)
            {
                np.add_cpu_time(x);
                cpu_time = !cpu_time;
            }
            else
            {
                np.add_IO_time(x);
                cpu_time = !cpu_time;
            }
            // break;
            ss >> x;
        }
        getline(file, line);

        processes.push_back(np);
    }
}

void preemptivesjf(long long time, int cpu_id)
{
    // if(cpu_busy[0])
    // {
    //     if(debug) cout<<"["<<time<<"]"<<"CPU is running "<<running_process[0]<<endl;
    //     return;
    // }

    if (prq.empty())
        return;
    if (cpu_busy[cpu_id])
    {
        // if (!cpu_busy[1 - cpu_id])
        //     return;
        {
            int most_busy_cpu = cpu_id;
            long long most_busy_time = processes[running_process[cpu_id]-1].get_next_cpu_burst();
            for (int i = 0; i < MAX_CPUS; i++)
            {
                if(debug) cout<<"CPU"<<i<<((cpu_busy[i])? " busy":" free")<<endl;
                if(i == cpu_id)
                    continue;
                if(!cpu_busy[i])
                {
                    return;
                }

                if (cpu_busy[i])
                {
                    Process* curr = &processes[running_process[i] - 1];
                    if(curr->get_next_cpu_burst() > most_busy_time)
                    {
                        most_busy_time = curr->get_next_cpu_burst();
                        most_busy_cpu = i;
                    }
                }
            }

            if(most_busy_cpu != cpu_id)
                return;
            
        }
    }
    Process *p = prq.top();
    if (cpu_busy[cpu_id])
    {
        Process *curr = &processes[running_process[cpu_id] - 1];
        // if(debug) cout<<"curr pid "<<curr->pid<<" curr rem "<<curr->get_next_cpu_burst()<<endl;
        // if(debug) cout<<"p pid "<<p->pid<<" p rem "<<p->get_next_cpu_burst()<<endl;
        if (curr->get_next_cpu_burst() <= p->get_next_cpu_burst())
        {
            // if(debug) cout<<"["<<time<<"]"<<"CPU is running "<<running_process[0]<<endl;
            return;
        }
        else
        {
            curr->stop(time - 1);
            prq.push(curr);

            if(debug) cout << "[" << time << "]" << "preempted " << curr->pid << endl;
        }
    }
    prq.pop();
    p->run(time, cpu_id);
    cpu_busy[cpu_id] = true;
    running_process[cpu_id] = p->pid;
    if(debug) cout << "[" << time << "]" << "scheduled " << p->pid << " on " << cpu_id << endl;
}
int main(int argc, char *argv[])
{
    if (argc != 2)
    {
        cout << "you dumbeo enter 2\n";
    }

    long long time = 0;
    int idx = 0;
    int inpf = 0;
    getInput(argv[1]);
    for (int i = 0; i < MAX_CPUS; i++)
    {
        cpu_busy[i] = false;
        running_process[i] = -1;
    }
    auto start = chrono::high_resolution_clock::now();
    while (1)
    {
        if(debug) cout << time << "-----------------------\n";
        while (idx < processes.size() && processes[idx].arrival_time == time)
        {
            prq.push(&processes[idx]);
            if(debug) cout << "[" << time << "]" << "process " << processes[idx].pid << " arrived" << endl;
            idx++;
            if (idx == processes.size())
                inpf = 1;
        }
        for (int i = 0; i < MAX_CPUS; i++)
            preemptivesjf(time, i);
        for (int i = 0; i < processes.size(); i++)
        {
            processes[i].update(time);
        }

        time++;
        if (terminated_processes == processes.size() && inpf)
        {
            if(debug) cout << "All processes terminated at time " << time << endl;
            break;
        }
        if (time == 30000)
        {
            if(debug) cout << "Time limit reached\n";
            break;
        }
        // break;
    }
    auto end = chrono::high_resolution_clock::now();
    auto duration = chrono::duration_cast<chrono::microseconds>(end - start);
    cout << "Time taken: " << duration.count() << " microseconds" << endl;
    long long total_turnaround_time = 0;
    for (int i = 0; i < processes.size(); i++)
    {
        total_turnaround_time += processes[i].turn_around_time;
        cout << "Process " << processes[i].pid << " turnaround time " << processes[i].turn_around_time << endl;
    }
    cout << "Average turnaround time " << (double)total_turnaround_time / processes.size() << endl;

    vector<vector<vector<long long>>> gantt_times(MAX_CPUS, vector<vector<long long>>(0, vector<long long>(4, 0)));
    for (int i = 0; i < processes.size(); i++)
    {
        //cout << "Process " << processes[i].pid << "burst times" << endl;
        for (int j = 0; j < processes[i].burst_times.size(); j++)
        {
            int cpu_id = processes[i].burst_times[j][2];
            gantt_times[cpu_id].push_back({processes[i].burst_times[j][0], processes[i].burst_times[j][1], (long long)processes[i].pid, (long long)j + 1});
            //cout << processes[i].burst_times[j][0] << " " << processes[i].burst_times[j][1] << " on cpu " << processes[i].burst_times[j][2] << endl;
        }
    }
    ofstream gantt_file("gantt_chart_psjf_multi_core.txt");
    for (int i = 0; i < MAX_CPUS; i++)
    {
        sort(gantt_times[i].begin(), gantt_times[i].end());
        gantt_file << "CPU" << i << endl;
        for (int j = 0; j < gantt_times[i].size(); j++)
        {
            gantt_file << "P" << gantt_times[i][j][2] << "," << gantt_times[i][j][3] << "\t\t" << gantt_times[i][j][0] << "\t\t" << gantt_times[i][j][1] << endl;
        }
    }

    gantt_file.close();
}
